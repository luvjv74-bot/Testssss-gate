const form = document.getElementById('payment-form');
const amount = document.getElementById('amount');
const total = document.getElementById('total');
const button = document.getElementById('pay');
const message = document.getElementById('message');
const fmt = n => '₱' + (Number(n)||0).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2});
amount.addEventListener('input', () => total.textContent = fmt(amount.value));
if (new URLSearchParams(location.search).has('cancelled')) message.textContent = 'Payment was cancelled. You can try again.';
form.addEventListener('submit', async e => {
  e.preventDefault(); message.textContent = '';
  const n = Number(amount.value);
  if (!Number.isFinite(n) || n < 1 || n > 100000) { message.textContent = 'Enter an amount from ₱1.00 to ₱100,000.00.'; return; }
  button.disabled = true; button.textContent = 'Creating secure checkout…';
  try {
    const response = await fetch('/api/checkout', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({amount:n,description:document.getElementById('description').value})});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Unable to start checkout.');
    location.href = data.checkoutUrl;
  } catch (err) { message.textContent = err.message; button.disabled = false; button.innerHTML = 'Continue to GCash <span>→</span>'; }
});
