require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const DATA_DIR = path.join(__dirname, 'data');
const PAYMENTS_FILE = path.join(DATA_DIR, 'payments.json');
const EVENTS_FILE = path.join(DATA_DIR, 'processed-events.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(PAYMENTS_FILE)) fs.writeFileSync(PAYMENTS_FILE, '[]');
if (!fs.existsSync(EVENTS_FILE)) fs.writeFileSync(EVENTS_FILE, '[]');

function readJson(file) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return []; } }
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2)); }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function verifyPayMongoSignature(rawBody, header, secret) {
  if (!header || !secret) return false;
  const parts = Object.fromEntries(header.split(',').map(p => {
    const i = p.indexOf('='); return i < 0 ? [p, ''] : [p.slice(0, i).trim(), p.slice(i + 1).trim()];
  }));
  if (!parts.t) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${parts.t}.${rawBody.toString('utf8')}`).digest('hex');
  // PayMongo supplies te for test mode and li for live mode.
  return [parts.te, parts.li].filter(Boolean).some(sig => safeEqual(expected, sig));
}

// Webhook route MUST be registered before express.json() so the original bytes are preserved.
app.post('/webhooks/paymongo', express.raw({ type: 'application/json' }), (req, res) => {
  const secret = process.env.PAYMONGO_WEBHOOK_SECRET;
  if (!secret || !verifyPayMongoSignature(req.body, req.get('Paymongo-Signature'), secret)) {
    return res.sendStatus(401);
  }
  let payload;
  try { payload = JSON.parse(req.body.toString('utf8')); } catch { return res.sendStatus(400); }
  // PayMongo wraps the event resource in payload.data. The event type and
  // Checkout Session resource are nested under payload.data.attributes.
  const event = payload?.data;
  const eventId = event?.id;
  const eventType = event?.attributes?.type;
  const session = event?.attributes?.data;
  if (!eventId || !eventType) return res.sendStatus(400);
  const processed = readJson(EVENTS_FILE);
  if (processed.includes(eventId)) return res.sendStatus(200);
  processed.push(eventId);
  writeJson(EVENTS_FILE, processed);

  if (eventType === 'checkout_session.payment.paid') {
    const attrs = session?.attributes || {};
    const ref = attrs.reference_number;
    const payments = readJson(PAYMENTS_FILE);
    const match = payments.find(p => p.referenceNumber === ref || p.sessionId === session.id);
    if (match) {
      match.status = 'paid';
      match.paidAt = new Date().toISOString();
      match.sessionId = session.id;
      writeJson(PAYMENTS_FILE, payments);
    }
  }
  return res.sendStatus(200);
});

app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/checkout', async (req, res) => {
  try {
    const key = process.env.PAYMONGO_SECRET_KEY;
    if (!key || !key.startsWith('sk_test_') && !key.startsWith('sk_live_')) {
      return res.status(503).json({ error: 'Payment gateway is not configured yet. Add your PayMongo secret key on the server.' });
    }
    const amount = Number(req.body?.amount);
    const description = String(req.body?.description || 'Payment').trim().slice(0, 80);
    if (!Number.isFinite(amount) || amount < 1 || amount > 100000) {
      return res.status(400).json({ error: 'Enter an amount from PHP 1.00 to PHP 100,000.00.' });
    }
    const centavos = Math.round(amount * 100);
    const referenceNumber = `TEST-${Date.now()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const payload = {
      data: { attributes: {
        line_items: [{ name: description || 'Payment', amount: centavos, currency: 'PHP', quantity: 1 }],
        payment_method_types: ['gcash'],
        reference_number: referenceNumber,
        success_url: `${BASE_URL}/success?ref=${encodeURIComponent(referenceNumber)}`,
        cancel_url: `${BASE_URL}/?cancelled=1`
      }}
    };
    const response = await fetch('https://api.paymongo.com/v2/checkout_sessions', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${Buffer.from(`${key}:`).toString('base64')}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) {
      console.error('PayMongo API error:', JSON.stringify(result));
      return res.status(502).json({ error: 'PayMongo could not create checkout. Check that GCash is enabled for your account and review the server logs.' });
    }
    const checkoutUrl = result?.data?.attributes?.checkout_url;
    if (!checkoutUrl) return res.status(502).json({ error: 'PayMongo did not return a checkout URL.' });
    const payments = readJson(PAYMENTS_FILE);
    payments.push({ referenceNumber, amount: (centavos / 100).toFixed(2), description, status: 'pending', createdAt: new Date().toISOString(), sessionId: result.data.id });
    writeJson(PAYMENTS_FILE, payments);
    return res.json({ checkoutUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

app.get('/success', (req, res) => res.sendFile(path.join(__dirname, 'public', 'success.html')));
app.get('/api/payment-status', (req, res) => {
  const ref = String(req.query.ref || '');
  const payment = readJson(PAYMENTS_FILE).find(p => p.referenceNumber === ref);
  if (!payment) return res.status(404).json({ error: 'Payment reference not found.' });
  return res.json({ referenceNumber: payment.referenceNumber, amount: payment.amount, status: payment.status, description: payment.description });
});

app.listen(PORT, () => console.log(`Test GCash Gateway running at ${BASE_URL}`));
