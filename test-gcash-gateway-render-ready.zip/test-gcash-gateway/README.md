# Test — GCash Payment Gateway (starter)

A small Express app using PayMongo Hosted Checkout API v2. Customers enter a PHP amount; the server creates a checkout session restricted to `gcash` and redirects the customer to PayMongo.

## Requirements
- Node.js 20+
- PayMongo account with GCash enabled for your merchant account
- A public HTTPS deployment URL for webhooks

## Run locally
1. Copy `.env.example` to `.env`.
2. Add your PayMongo **test** secret key to `PAYMONGO_SECRET_KEY`.
3. Add the webhook signing secret after you create a test-mode webhook in PayMongo to `PAYMONGO_WEBHOOK_SECRET`.
4. Set `BASE_URL=http://localhost:3000`.
5. Run `npm install` then `npm start`.
6. Open http://localhost:3000.

## Webhook setup
After deploying to a public HTTPS URL, open PayMongo Dashboard → Developer Tools → Webhooks. Add `https://YOUR-DOMAIN/webhooks/paymongo` and subscribe to `checkout_session.payment.paid`. Copy the endpoint signing secret into `PAYMONGO_WEBHOOK_SECRET` on the server. Test and live webhooks are separate; create a separate endpoint/secret for each mode.

## Important notes
- The secret API key and webhook signing secret belong only in server environment variables. Never put them in browser JavaScript or commit `.env`.
- The success page is not proof of payment. The app marks a transaction `paid` only after a verified PayMongo webhook.
- This starter stores a lightweight local JSON transaction list. For production, use a managed database, durable event queue, webhook-event deduplication with database uniqueness, structured logs, HTTPS, backups, and monitoring.
- Amount limits are set to PHP 1.00–PHP 100,000.00; adjust `server.js` if your business rules and PayMongo account limits require a different range.
- Availability of GCash depends on your PayMongo account's enabled payment methods and eligibility.


## Deploy a test version on Render (no domain required)
1. Create a GitHub account and a new **private** repository named `test-gcash-gateway`.
2. Extract this ZIP on your computer, then upload the *contents* of the `test-gcash-gateway` folder to the repository root (so `package.json` and `server.js` are at the root).
3. In Render, choose **New → Web Service**, connect GitHub, and select that repository.
4. Use these settings:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
   - Instance type: Free (for testing only)
5. Add environment variables in Render:
   - `PAYMONGO_SECRET_KEY` = your PayMongo test secret key (`sk_test_...`)
   - `BASE_URL` = the HTTPS `onrender.com` URL Render assigns to your service (no trailing slash)
   - `PAYMONGO_WEBHOOK_SECRET` = add this only after creating the test webhook in PayMongo
6. Deploy. Open the Render URL and test the checkout.
7. In PayMongo Dashboard → Settings → Webhooks, create a **test-mode** endpoint:
   `https://YOUR-RENDER-SERVICE.onrender.com/webhooks/paymongo`
   Subscribe to `checkout_session.payment.paid`, then copy the webhook signing secret into Render as `PAYMONGO_WEBHOOK_SECRET` and redeploy.
8. Make a test payment and confirm the status changes only after the verified webhook.

Important: Render Free services sleep after 15 minutes idle and their local filesystem is temporary. This starter stores transaction records in local JSON files, so records can be lost on restarts/redeploys/sleep. This is only for learning and test transactions—not production or storing real customer/payment records. Before accepting real money, move transactions and webhook idempotency to a persistent managed database, add monitoring/backups, and use PayMongo live credentials only after end-to-end testing and merchant approval.
